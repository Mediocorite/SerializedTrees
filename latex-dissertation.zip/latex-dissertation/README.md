# LaTeX Dissertation

A dissertation template for undergraduate or postgraduate dissertations.  The title page content and the page margins have been chosen to comply with the university's policy concerning theses.

## Learning LaTeX

Documentation on LaTeX can be found at:
- [https://en.wikibooks.org/wiki/LaTeX](https://en.wikibooks.org/wiki/LaTeX)
- [https://www.overleaf.com/learn](https://www.overleaf.com/learn)
